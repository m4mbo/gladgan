Node labels:		[symbol]

Node attributes:	[chem, charge, x, y]

Edge labels:		[valence]

Node labels were converted to integer values using this map:

Component 0:
	0	C  
	1	O  
	2	N  
	3	Cl 
	4	F  
	5	S  
	6	Se 
	7	P  
	8	Na 
	9	I  
	10	Co 
	11	Br 
	12	Li 
	13	Si 
	14	Mg 
	15	Cu 
	16	As 
	17	B  
	18	Pt 
	19	Ru 
	20	K  
	21	Pd 
	22	Au 
	23	Te 
	24	W  
	25	Rh 
	26	Zn 
	27	Bi 
	28	Pb 
	29	Ge 
	30	Sb 
	31	Sn 
	32	Ga 
	33	Hg 
	34	Ho 
	35	Tl 
	36	Ni 
	37	Tb 



Edge labels were converted to integer values using this map:

Component 0:
	0	1
	1	2
	2	3



Class labels were converted to integer values using this map:

	0	a
	1	i


